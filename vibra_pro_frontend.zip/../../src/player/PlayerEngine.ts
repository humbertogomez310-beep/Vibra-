export class PlayerEngine {
  private audio: HTMLAudioElement;
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private gainNode: GainNode | null = null; // Nodo de hardware para controlar el volumen
  private dataArray: Uint8Array = new Uint8Array(32);
  private isInitialized: boolean = false;

  constructor() {
    this.audio = new Audio();
    this.audio.crossOrigin = "anonymous";
  }

  public load(url: string) {
    this.audio.src = url;
    this.audio.load();
    console.log("🎵 [PLAYER ENGINE] Pista de audio cargada en el buffer.");
  }

  private initAudioContext() {
    if (this.isInitialized) return;

    // Crear el contexto de audio nativo
    this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    this.analyser = this.audioContext.createAnalyser();
    this.analyser.fftSize = 64; // 32 barras de frecuencia

    // Crear el nodo de ganancia (volumen)
    this.gainNode = this.audioContext.createGain();

    const source = this.audioContext.createMediaElementSource(this.audio);
    
    // Conectar el flujo: Origen -> Ganancia -> Analizador -> Altavoces
    source.connect(this.gainNode);
    this.gainNode.connect(this.analyser);
    this.analyser.connect(this.audioContext.destination);

    this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.isInitialized = true;
    console.log("🎛️ [PLAYER ENGINE] Hardware Web Audio conectado exitosamente.");
  }

  public play() {
    this.initAudioContext();
    if (this.audioContext && this.audioContext.state === "suspended") {
      this.audioContext.resume();
    }
    this.audio.play().catch(err => console.error("Error al reproducir:", err));
  }

  public stop() {
    this.audio.pause();
  }

  // Método clave para actualizar los decibelios reales
  public setHardwareVolume(level: number) {
    this.initAudioContext();
    if (this.gainNode) {
      // Modifica la ganancia real del nodo de audio (de 0.0 a 1.0)
      this.gainNode.gain.setValueAtTime(level, this.audioContext!.currentTime);
    }
  }

  public getFrequencies(): Uint8Array {
    if (this.analyser) {
      this.analyser.getByteFrequencyData(this.dataArray);
    }
    return this.dataArray;
  }
}
